<?php
function pembagian($num1, $num2)
{
    if ($num1 < $num2) {
        echo "nilai pertama harus lebih besar daripada nilai kedua";
    } else {
        $num3 = $num1 / $num2;
        echo round($num3, 0);
    }
}

pembagian(8, 6);
