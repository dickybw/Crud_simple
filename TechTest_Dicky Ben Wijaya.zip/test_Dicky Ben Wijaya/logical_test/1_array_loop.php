<?php

$aplikasi[1] = 'gtAkademik';
$aplikasi[2] = 'gtFinansi';
$aplikasi[3] = 'gtPerizinan';
$aplikasi[4] = 'eCampuz';
$aplikasi[5] = 'e0viz';

$a = 1;
while ($a <= 5) {
    echo $aplikasi[$a];
    echo '<br>';
    $a++;
}
