<?php

$a = 1;

while ($a <= 50) {
    if ($a % 3 === 0) {
        echo "$a Foo";
        if ($a % 3 === 0 && $a % 5 === 0) {
            echo " || FooBar";
        } 
    } else if ($a % 5 === 0) {
        echo "$a Bar";
        if ($a % 3 === 0 && $a % 5 === 0) {
            echo " || FooBar";
        } 
    } else {
        echo $a;
    }
    echo '<br>';
    $a++;
}
