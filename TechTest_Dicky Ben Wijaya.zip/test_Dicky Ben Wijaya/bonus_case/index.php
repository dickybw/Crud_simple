<?php
session_start();
require 'conn.php';
if (isset($_SESSION["login"])) {
    header("Location: dashboard.php");
    exit;
}

if (isset($_POST["login"])) {

    $username = $_POST["username"];
    $password = sha1($_POST["password"]);

    $result = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username' AND password = '$password'");

    // cek username
    if (mysqli_num_rows($result) === 1) {

        $_SESSION["login"] = true;

        header("Location: dashboard.php");
        exit;
    }

    $error = true;
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-sm-6 col-md-6">
                <div class="card">
                    <div class="card-header">
                        Login (username/password === asd123)
                    </div>
                    <div class="card-body">
                        <form action="" method="post">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" name="username" id="username">
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" name="password" id="password">
                            </div>
                            <?php if (isset($error)) : ?>
                                <div id="alert" class="form-text mb-2 text-center text-danger">username / password salah</div>
                            <?php endif; ?>
                            <div class="d-grid gap-2">
                                <button class="btn btn-primary login" type="submit" name="login">Go!</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {

        });
    </script>
</body>

</html>